package com.capgemini.doctors.service;

import java.util.regex.Pattern;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;


public class DoctorAppointmentService implements IDoctorAppointmentService {

	DoctorAppointmentDao dao = new DoctorAppointmentDao();

	DoctorAppointment doctorAppointment = new DoctorAppointment();

	
	int id = (int) (Math.random()*100);
	

	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) {
		int id = (int) (Math.random()*100);
				doctorAppointment.setAppointmentId(id);
		return dao.addDoctorAppointmentDetails(doctorAppointment);
	}

	@Override
	public DoctorAppointment getDoctorAppointmentDetails(int appointmentId) {
		// TODO Auto-generated method stub
		return dao.getAppointmentDetails(appointmentId);
	}

	public boolean validate_patientName(String patientName) 
	{
		
		return Pattern.matches("[a-zA-Z]*",patientName);
	}
	public boolean validate_phoneNumber(String phoneNumber) 
	{
		return Pattern.matches("[6-9]{1}[0-9]{9}", phoneNumber);
	}
	public boolean validate_age(int age) 
	{
				return (age>0 && age<100);
	}
	public boolean validate_problemName(String problemName) 
	{
		
		return Pattern.matches("[a-zA-Z]*",problemName);
	}
	public boolean validate_gender(String gender) 
	{
		
		return gender.equals("Female")||gender.equals("Male")||gender.equals("Transgender");
	}
	public boolean validate_email(String email) 
	{
		
		return Pattern.matches("\\D*\\d*",email);
	}
	public void setApproval(String problemName,DoctorAppointment doctorAppointment){
		if(problemName.equals("Heart")){
			doctorAppointment.setAppointmentStatus("APPROVED");
			doctorAppointment.setDoctorName("Dr. Brijesh kumar");
		}else{
			if(problemName.equals("Gynecology")){
				doctorAppointment.setAppointmentStatus("APPROVED");
				doctorAppointment.setDoctorName("Dr. Sharda Singh");
			}else{
				if(problemName.equals("Diabetes")){
					doctorAppointment.setAppointmentStatus("APPROVED");
					doctorAppointment.setDoctorName("Dr. heena Khan");
				}else{
					if(problemName.equals("ENT")){
						doctorAppointment.setAppointmentStatus("APPROVED");
						doctorAppointment.setDoctorName("Dr. para mal");
					}else{
						if(problemName.equals("Bone")){
							doctorAppointment.setAppointmentStatus("APPROVED");
							doctorAppointment.setDoctorName("Dr. Renuka Kher");
						}else{
							if(problemName.equals("Dermatology")){
								doctorAppointment.setAppointmentStatus("APPROVED");
								doctorAppointment.setDoctorName("Dr. Kanika Kapoor");
							}else{
								doctorAppointment.setAppointmentStatus("DISAPPROVED");
								doctorAppointment.setDoctorName("null");
							}
						}
					}
				}
				
			}
		}
		
	}
}
