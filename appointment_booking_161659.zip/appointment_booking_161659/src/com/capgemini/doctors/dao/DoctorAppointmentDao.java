package com.capgemini.doctors.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.doctors.bean.DoctorAppointment;

public class DoctorAppointmentDao implements IDoctorAppointmentDao {

	Map<Integer,DoctorAppointment> appointments = new HashMap<Integer,DoctorAppointment>();
	
	DoctorAppointment doctorAppointment = new DoctorAppointment();
	
	HashMap<String , String> doctorlist = new HashMap<String , String>();

	

	
	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) {
		// TODO Auto-generated method stub
		
		
		appointments.put(doctorAppointment.getAppointmentId(), doctorAppointment);
		
		return 0;
	}

	@Override
	public DoctorAppointment getAppointmentDetails(int appointmentId) {
		// TODO Auto-generated method stub
		System.out.println(appointments);
		boolean f= false;
		for(Map.Entry<Integer,DoctorAppointment> it: appointments.entrySet())
		{
			if(f==false)
			doctorAppointment=appointments.get(it.getKey());
			
			if(doctorAppointment.getAppointmentId() == appointmentId && f==false)
			{		f=true;
			//return doctorAppointment;
			}
			}
		return doctorAppointment;
		
		
	}

}
