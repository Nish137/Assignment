package ciom.capgemini.doctors.test;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Assert;
import org.junit.Test;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;



    
public class DoctorAppointmentDaoTest {
	
	DoctorAppointmentDao dao=new DoctorAppointmentDao();
	DoctorAppointment bean=new DoctorAppointment(1234, "matte", "9888522003", "nish@gmail.com", "male", 21, "ENT", "Dr.paras", "APPROVED");	
	
		
	

	@Test
	public void testAddDoctorAppointmentDetails() {
		 assertNotNull(dao.addDoctorAppointmentDetails(bean));
	}

	@Test
	public void testGetAppointmentDetails() {
	assertNotNull(dao.getAppointmentDetails(bean.getAppointmentId()));
	}


}