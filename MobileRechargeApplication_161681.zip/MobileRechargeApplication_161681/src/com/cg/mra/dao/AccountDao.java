package com.cg.mra.dao;

import comcg.mra.beans.Account;

public interface AccountDao {
	Account getAccountDetails(String mobileNo);
	int rechargeAccount(String mobileno, double rechargeAmount);

}
