package com.cg.mra.test;

import static org.junit.Assert.fail;

import org.junit.Test;

import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class AccountDaoImplTest {
	AccountService service=new AccountServiceImpl();

	@Test
	public void testRechargeAccount() {
		
	}

}
