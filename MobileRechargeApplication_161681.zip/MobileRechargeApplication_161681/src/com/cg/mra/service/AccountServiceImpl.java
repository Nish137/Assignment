package com.cg.mra.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.MobileException;

import comcg.mra.beans.Account;

public class AccountServiceImpl implements AccountService {
	
	AccountDao dao=new AccountDaoImpl();

	@Override
	public Account getAccountDetails(String mobileNo) {
		// TODO Auto-generated method stub
		return dao.getAccountDetails(mobileNo);
	}

	@Override
	public int rechargeAccount(String mobileno, double rechargeAmount) {
		// TODO Auto-generated method stub
		return dao.rechargeAccount(mobileno, rechargeAmount);
	}
	@Override
	 public boolean validateMobileNo(String mobileNo)
	            throws MobileException {
	        // TODO Auto-generated method stub
	        if(mobileNo == null)
	            throw new MobileException("Null value found");
	        Pattern p = Pattern.compile("[6-9][0-9]{9}");
	        Matcher m = p.matcher(mobileNo);
	        return m.matches();
	    }

	    @Override
	    public boolean validateRechargeAmount(Double rechargeAmount)
	            throws MobileException {
	        // TODO Auto-generated method stub
	        if(rechargeAmount == null)
	            throw new MobileException("Null value found");
	        String ra = rechargeAmount.toString();
	        return (ra.matches("\\d{2,4}\\.\\d{0,4}"));
	    }

	    }

