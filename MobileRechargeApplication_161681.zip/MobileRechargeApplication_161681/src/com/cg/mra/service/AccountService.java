package com.cg.mra.service;

import com.cg.mra.exception.MobileException;

import comcg.mra.beans.Account;

public interface AccountService {
	Account getAccountDetails(String mobileNo);
	int rechargeAccount(String mobileno, double rechargeAmount);
	boolean validateRechargeAmount(Double rechargeAmount) throws MobileException;
	boolean validateMobileNo(String mobileNo) throws MobileException;

}
