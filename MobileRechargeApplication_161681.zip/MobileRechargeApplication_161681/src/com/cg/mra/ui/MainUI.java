package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

import comcg.mra.beans.Account;

public class MainUI {

	public static void main(String[] args) {
		
		Account account=new Account();
		AccountService service=new AccountServiceImpl();
		Scanner sc =new Scanner(System.in);
		int choice=0;
		
		while(true){ 
			
			System.out.println("\n____________MENU________________\n");
		    System.out.println("1.Account Balance Enquiry ");
		    System.out.println("2.Recharge Account");
		    System.out.println("3.Exit\n");
		    
		    System.out.println("Please Enter the option:");
		  choice=    sc.nextInt();
		  
		  switch (choice) {
		case 1:
			System.out.println("Enter The Mobile Number");
			String mobileNo=sc.next();
		    account=service.getAccountDetails(mobileNo);
		 if(account == null)
	            System.out.println("ERROR: Given Account Id Does Not Exists");
	        //if the entered mobile number does not exist in the list it will display an error
	        else{
	            System.out.println("Your Current Balance is Rs." +account.getAccountBalance()); //prints the current accountBalance
	            }
	        
	            break;
			
		case 2:
			System.out.println("Enter the Mobile Number");
			String mobileno=sc.next();
			System.out.println("Enter the reharge Amount");
			double rechargeAmount=sc.nextDouble();
			account = service.getAccountDetails(mobileno);
	        double recharge = service.rechargeAccount(mobileno, rechargeAmount);
	        if(account == null){
	            System.out.println("ERROR: Cannot Recharge Account as Given Mobile No Does Not Exists");
	        }
	        else{
	            account.setAccountBalance(account.getAccountBalance()+recharge); //if the mobile get recharged successful
	            System.out.println("Your Account Recharged Successfully");
	            System.out.println("Hello "+account.getCustomerName() + ","+"Available Balance is "+account.getAccountBalance());
	        }
	        break; 
	        
		case 3:
			System.out.println
		  ("Thank you for using services");
			System.exit(0);
		 
			break;

		default:
			
			System.out.println("Please enter valid choice:");
			break;
		}
		  
	

	}

}
}
