$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/TEducationDeatils.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author:Shiva Kumar"
    }
  ],
  "line": 2,
  "name": "Education Deatils",
  "description": "",
  "id": "education-deatils",
  "keyword": "Feature"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "TEducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 4352809663,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "Test the Title",
  "description": "",
  "id": "education-deatils;test-the-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "Checks the heading of the page",
  "keyword": "Then "
});
formatter.match({
  "location": "TEducationStepDef.checks_the_heading_of_the_page()"
});
formatter.result({
  "duration": 3211542949,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "TEducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 2880831197,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Failure on not selecting the graduation",
  "description": "",
  "id": "education-deatils;failure-on-not-selecting-the-graduation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "user not selects the graduation and clicks the Register me",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "dispaly error message",
  "keyword": "Then "
});
formatter.match({
  "location": "TEducationStepDef.user_not_selects_the_graduation_and_clicks_the_Register_me()"
});
formatter.result({
  "duration": 3170562487,
  "status": "passed"
});
formatter.match({
  "location": "TEducationStepDef.dispaly_error_message()"
});
formatter.result({
  "duration": 489888644,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "TEducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 2619099896,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Failure in login apge on leaving percentage empty",
  "description": "",
  "id": "education-deatils;failure-in-login-apge-on-leaving-percentage-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user levaes the percentage blank and clicks Register me",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "print  error message",
  "keyword": "Then "
});
formatter.match({
  "location": "TEducationStepDef.user_levaes_the_percentage_blank_and_clicks_Register_me()"
});
formatter.result({
  "duration": 3412227665,
  "status": "passed"
});
formatter.match({
  "location": "TEducationStepDef.print_error_message()"
});
formatter.result({
  "duration": 136557169,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "TEducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 2543088835,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Failure in login apge on leaving passsing year empty",
  "description": "",
  "id": "education-deatils;failure-in-login-apge-on-leaving-passsing-year-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "user levaes the passsing  blank and clicks Register me",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "Display an error message",
  "keyword": "Then "
});
formatter.match({
  "location": "TEducationStepDef.user_levaes_the_passsing_blank_and_clicks_Register_me()"
});
formatter.result({
  "duration": 3495526615,
  "status": "passed"
});
formatter.match({
  "location": "TEducationStepDef.display_an_error_message()"
});
formatter.result({
  "duration": 160424465,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "TEducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 2608520273,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "Failure in login apge on leaving Projec tName empty",
  "description": "",
  "id": "education-deatils;failure-in-login-apge-on-leaving-projec-tname-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 23,
  "name": "user levaes the Project blank and clicks Register me",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "display  the error message",
  "keyword": "Then "
});
formatter.match({
  "location": "TEducationStepDef.user_levaes_the_Project_blank_and_clicks_Register_me()"
});
formatter.result({
  "duration": 3589961134,
  "status": "passed"
});
formatter.match({
  "location": "TEducationStepDef.display_the_error_message()"
});
formatter.result({
  "duration": 126349173,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "TEducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 2620579148,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "Failure on not selecting the technologies",
  "description": "",
  "id": "education-deatils;failure-on-not-selecting-the-technologies",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 27,
  "name": "user not selects the technologies and clicks on Making payment",
  "keyword": "When "
});
formatter.step({
  "line": 28,
  "name": "dispaly error message for technologies",
  "keyword": "Then "
});
formatter.match({
  "location": "TEducationStepDef.user_not_selects_the_technologies_and_clicks_on_Making_payment()"
});
formatter.result({
  "duration": 3911342971,
  "status": "passed"
});
formatter.match({
  "location": "TEducationStepDef.dispaly_error_message_for_technologies()"
});
formatter.result({
  "duration": 129841011,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "TEducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 2612206245,
  "status": "passed"
});
formatter.scenario({
  "line": 30,
  "name": "Failure on not filling the technologies",
  "description": "",
  "id": "education-deatils;failure-on-not-filling-the-technologies",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 31,
  "name": "user not selects the Other and not filled the form",
  "keyword": "When "
});
formatter.step({
  "line": 32,
  "name": "dispaly error message for other technologies",
  "keyword": "Then "
});
formatter.match({
  "location": "TEducationStepDef.user_not_selects_the_Other_and_not_filled_the_form()"
});
formatter.result({
  "duration": 3856768915,
  "status": "passed"
});
formatter.match({
  "location": "TEducationStepDef.dispaly_error_message_for_other_technologies()"
});
formatter.result({
  "duration": 3903999,
  "error_message": "org.junit.ComparisonFailure: expected:\u003c[Your Registration Has succesfully done Plz check you registerd email for account activation link !!!]\u003e but was:\u003c[Please fill other Technologies Used]\u003e\r\n\tat org.junit.Assert.assertEquals(Assert.java:115)\r\n\tat org.junit.Assert.assertEquals(Assert.java:144)\r\n\tat features.TEducationStepDef.dispaly_error_message_for_other_technologies(TEducationStepDef.java:175)\r\n\tat ✽.Then dispaly error message for other technologies(features/TEducationDeatils.feature:32)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "TEducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 2677248138,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "succesfull Registration of Education",
  "description": "",
  "id": "education-deatils;succesfull-registration-of-education",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "user enter all valid Education details",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "print the suceess message",
  "keyword": "Then "
});
formatter.match({
  "location": "TEducationStepDef.user_enter_all_valid_Education_details()"
});
formatter.result({
  "duration": 4020132258,
  "status": "passed"
});
formatter.match({
  "location": "TEducationStepDef.print_the_suceess_message()"
});
formatter.result({
  "duration": 212895909,
  "status": "passed"
});
formatter.uri("features/personal.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author:Shiva Kumar"
    }
  ],
  "line": 2,
  "name": "Personal Deatils Page",
  "description": "",
  "id": "personal-deatils-page",
  "keyword": "Feature"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2471836812,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "verify the title",
  "description": "",
  "id": "personal-deatils-page;verify-the-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "check the heading of the page",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.check_the_heading_of_the_page()"
});
formatter.result({
  "duration": 3190615386,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2707052071,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Failure in login page on leaving first Name blank",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-leaving-first-name-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "user leaves first name blank and clicks the next",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "display error message for firstname",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_leaves_first_name_blank_and_clicks_the_next()"
});
formatter.result({
  "duration": 3240507204,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_firstname()"
});
formatter.result({
  "duration": 164277263,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2662597264,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Failure in login page on leaving last Name blank",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-leaving-last-name-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user leaves last name blank and clicks the next",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "display error message for last name",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_leaves_last_name_blank_and_clicks_the_next()"
});
formatter.result({
  "duration": 3395942658,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_last_name()"
});
formatter.result({
  "duration": 132607090,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2428301470,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Failure in login page on Entering wrong email format",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-entering-wrong-email-format",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "user enters wrong email and clicks the next",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "display error message for email",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_enters_wrong_email_and_clicks_the_next()"
});
formatter.result({
  "duration": 3628647838,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_email()"
});
formatter.result({
  "duration": 119418402,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2620516002,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "Failure in login page on leaving  conatact number  blank",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-leaving--conatact-number--blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 23,
  "name": "user leaves conatact number blank and clicks the next",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "display error message for contact number",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_leaves_conatact_number_blank_and_clicks_the_next()"
});
formatter.result({
  "duration": 3793443502,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_contact_number()"
});
formatter.result({
  "duration": 124538400,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2681535282,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "Failure in login page on Entering  Wrong Conatact number format",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-entering--wrong-conatact-number-format",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 27,
  "name": "user enters wrong Conatact no and clicks the next",
  "keyword": "When "
});
formatter.step({
  "line": 28,
  "name": "display error message for wrong contact number",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_enters_wrong_Conatact_no_and_clicks_the_next()"
});
formatter.result({
  "duration": 3982557448,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_wrong_contact_number()"
});
formatter.result({
  "duration": 297391233,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2659669479,
  "status": "passed"
});
formatter.scenario({
  "line": 30,
  "name": "Failure in login page on leaving Address line blank",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-leaving-address-line-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 31,
  "name": "user leaves Addressline  blank and clicks the next",
  "keyword": "When "
});
formatter.step({
  "line": 32,
  "name": "display error message for  an address",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_leaves_Addressline_blank_and_clicks_the_next()"
});
formatter.result({
  "duration": 3801636778,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_an_address()"
});
formatter.result({
  "duration": 378069599,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2542993688,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "Failure in login page on leaving Address line empty",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-leaving-address-line-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "user leaves Addressline empty and clicks the next",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "display error message for  the address",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_leaves_Addressline_empty_and_clicks_the_next()"
});
formatter.result({
  "duration": 3975519584,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_the_address()"
});
formatter.result({
  "duration": 131243464,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2592098734,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "Failure in login page on not selecting the city",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-not-selecting-the-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 39,
  "name": "user not selecting the city and clicks next",
  "keyword": "When "
});
formatter.step({
  "line": 40,
  "name": "Display error message for city",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_not_selecting_the_city_and_clicks_next()"
});
formatter.result({
  "duration": 4275306122,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_city()"
});
formatter.result({
  "duration": 123371468,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2627150239,
  "status": "passed"
});
formatter.scenario({
  "line": 42,
  "name": "Failure in login page on not selecting the State",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-not-selecting-the-state",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 43,
  "name": "user not selecting the State and clicks next",
  "keyword": "When "
});
formatter.step({
  "line": 44,
  "name": "Display error message for state",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_not_selecting_the_State_and_clicks_next()"
});
formatter.result({
  "duration": 4136949702,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_state()"
});
formatter.result({
  "duration": 2130713544,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2594689453,
  "status": "passed"
});
formatter.scenario({
  "line": 46,
  "name": "succesfull login with all valid data",
  "description": "",
  "id": "personal-deatils-page;succesfull-login-with-all-valid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 47,
  "name": "user enter all valid details",
  "keyword": "When "
});
formatter.step({
  "line": 48,
  "name": "navigate to Educational deatails form",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_enter_all_valid_details()"
});
formatter.result({
  "duration": 4493574616,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.navigate_to_Educational_deatails_form()"
});
formatter.result({
  "duration": 2548544619,
  "status": "passed"
});
});