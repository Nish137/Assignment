package features;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.personal.EducationPageFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TEducationStepDef {
	
	private EducationPageFactory edu ;
	private WebDriver driver;
	

	@Given("^user on the webpage$")
	public void user_on_the_webpage() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\asus\\Downloads\\chromedriver.exe");
		driver = new ChromeDriver();
		edu=new EducationPageFactory (driver);
	    driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	    driver.get("file:///C:/workspace/PersonalDetails_161681/src/test/java/features/TEducation.html");
	    
	   
	    // Write code here that turns the phrase above into concrete actions
	  
	}

	@Then("^Checks the heading of the page$")
	public void checks_the_heading_of_the_page() throws Throwable {
		String strheading=driver.findElement(By.xpath("/html/body/h4")).getText();
		if(strheading.contentEquals("Step 2: Educational Details"))
			System.out.println("********** Heading Matched");
		else
			System.out.println("********** Heading Not Matched");
		Thread.sleep(3000);
		driver.close();
		
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^user not selects the graduation and clicks the Register me$")
	public void user_not_selects_the_graduation_and_clicks_the_Register_me() throws Throwable {
		//edu.setGraduation();
		edu.setRegister();
		Thread.sleep(3000);
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^dispaly error message$")
	public void dispaly_error_message() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please Select Graduation");
		System.out.println("*******************"+alertMessage);
		driver.close();
		
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^user levaes the percentage blank and clicks Register me$")
	public void user_levaes_the_percentage_blank_and_clicks_Register_me() throws Throwable {
	      edu.setGraduation("BE");
	      edu.setPercentage("");
				edu.setRegister();
				Thread.sleep(3000);
		
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^print  error message$")
	public void print_error_message() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please fill Percentage detail");
		System.out.println("*******************"+alertMessage);
		driver.close();
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^user levaes the passsing  blank and clicks Register me$")
	public void user_levaes_the_passsing_blank_and_clicks_Register_me() throws Throwable {
		edu.setGraduation("BE");
		edu.setPercentage("60");
		edu.setPassing("");
		edu.setRegister();
		Thread.sleep(3000);
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^Display an error message$")
	public void display_an_error_message() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please fill Passing Year");
		System.out.println("*******************"+alertMessage);
		driver.close();
		
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user levaes the Project blank and clicks Register me$")
	public void user_levaes_the_Project_blank_and_clicks_Register_me() throws Throwable {
		edu.setGraduation("BE");
		edu.setPercentage("60");
		edu.setPassing("2018");
		edu.setProjectName("");
		edu.setRegister();
		Thread.sleep(3000);
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^display  the error message$")
	public void display_the_error_message() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please fill Project Name");
		System.out.println("*******************"+alertMessage);
		driver.close();
		
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^user not selects the technologies and clicks on Making payment$")
	public void user_not_selects_the_technologies_and_clicks_on_Making_payment() throws Throwable {
		edu.setGraduation("BE");
		edu.setPercentage("60");
		edu.setPassing("2018");
		edu.setProjectName("Online Voting System");
		//edu.setOther();
		edu.setRegister();
		Thread.sleep(3000);
		
	    // Write code here that turns the phrase above into concrete actions
	    
	}
	@Then("^dispaly error message for technologies$")
	public void dispaly_error_message_for_technologies() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please Select Technologies Used");
		System.out.println("*******************"+alertMessage);
		driver.close();
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	

	@When("^user not selects the Other and not filled the form$")
	public void user_not_selects_the_Other_and_not_filled_the_form() throws Throwable {
		edu.setGraduation("BE");
		edu.setPercentage("60");
		edu.setPassing("2018");
		edu.setProjectName("Online Voting System");
	    edu.setJava();
	    edu.setOtherTechology("");
		edu.setRegister();
		Thread.sleep(3000);
	    // Write code here that turns the phrase above into concrete actions
	    
	}
	@Then("^dispaly error message for other technologies$")
	public void dispaly_error_message_for_other_technologies() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please fill other Technologies Used");
		System.out.println("*******************"+alertMessage);
		driver.close();
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^user enter all valid Education details$")
	public void user_enter_all_valid_Education_details() throws Throwable {
		
		edu.setGraduation("BE");
		edu.setPercentage("60");
		edu.setPassing("2018");
		edu.setProjectName("Online Voting System");
	    edu.setJava();
	   // edu.setOtherTechology("Python");
		edu.setRegister();
		Thread.sleep(3000);
		
	
	    // Write code here that turns the phrasbove into concrete actions
	   
	}

	@Then("^print the suceess message$")
	public void print_the_suceess_message() throws Throwable {
		
		
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Your Registration Has succesfully done Plz check you registerd email for account activation link !!!");
		System.out.println("*******************"+alertMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	    // Write code here that turns the phrase above into concrete actions
	    
	}




