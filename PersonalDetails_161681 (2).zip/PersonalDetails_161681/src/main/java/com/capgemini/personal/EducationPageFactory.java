package com.capgemini.personal;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class EducationPageFactory {
	
	WebDriver wd;
	public EducationPageFactory(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}

	
	
	@FindBy(xpath="/html/body/h4")
	@CacheLookup
	WebElement title;
	  
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[1]/td[2]/select")
	@CacheLookup
	WebElement graduation;
	public Select getSelectOptions(WebElement select) {
		return new Select(select);
	}
	
	@FindBy(xpath="//*[@id=\"txtPercentage\"]")
	@CacheLookup
	WebElement percentage;
	
	@FindBy(xpath="//*[@id=\"txtPassYear\"]")
	@CacheLookup
	WebElement passing;
	
	
	@FindBy(xpath="//*[@id=\"txtProjectName\"]")
	@CacheLookup
	WebElement projectName;
	
	
	@FindBy(xpath="//*[@id=\".net\"]")
	@CacheLookup
	WebElement net;
	
	@FindBy(xpath="//*[@id=\"java\"]")
	@CacheLookup
	WebElement java;
	
	
	@FindBy(xpath="//*[@id=\"php\"]")
	@CacheLookup
	WebElement php;
	@FindBy(xpath="//*[@id=\"others\"]")
	@CacheLookup
	WebElement other;
	
	@FindBy(xpath="//*[@id=\"txtOtherTechs\"]")
	@CacheLookup
	WebElement otherTechology;
	
	@FindBy(xpath="//*[@id=\"btnRegister\"]")
	@CacheLookup
	WebElement register;
	
	

	public WebElement getTitle() {
		return title;
	}

	public void setTitle(WebElement title) {
		this.title = title;
	}

	public String getGraduation() {
		return  getSelectOptions(graduation).getFirstSelectedOption().getText();
	}

	public void setGraduation(String  value) {
		getSelectOptions(graduation).selectByVisibleText(value);
	}

	public WebElement getPercentage() {
		return percentage;
	}

	public void setPercentage(String percentage) {
		this.percentage .sendKeys(percentage);
	}

	public WebElement getPassing() {
		return passing;
	}

	public void setPassing(String passing) {
		this.passing.sendKeys(passing);
	}

	public WebElement getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName.sendKeys(projectName);
	}

	public WebElement getNet() {
		return net;
	}

	public void setNet() {
		this.net.click();
	}

	public WebElement getJava() {
		return java;
	}

	public void setJava() {
	java .click();
	}

	public WebElement getPhp() {
		return php;
	}

	public void setPhp() {
	php .click();
	}

	public WebElement getOther() {
		return other;
	}

	public void setOther() {
		other.click();
	}

	public WebElement getOtherTechology() {
		return otherTechology;
	}

	public void setOtherTechology(String otherTechology) {
		this.otherTechology .sendKeys(otherTechology);
	}

	public WebElement getRegister() {
		return register;
	}

	public void setRegister() {
	    register .click();
	}

}
