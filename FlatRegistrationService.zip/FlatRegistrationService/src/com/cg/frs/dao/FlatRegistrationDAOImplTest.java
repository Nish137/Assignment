package com.cg.frs.dao;

import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.Test;

import com.cg.frs.dto.FlatRegistrationDTO;

public class FlatRegistrationDAOImplTest {
	
	FlatRegistrationDTO flat=new FlatRegistrationDTO(1, "2", 600, 6000.00, 25000.00, 1112);
    FlatRegistrationDAOImpl dao=new FlatRegistrationDAOImpl();		
	ArrayList<Integer> list=dao.getAllOwnerIds();


	@Test
	public void testRegisterFlat() {
		assertNotNull(flat);
	}

	@Test
	public void testGetAllOwnerIds() {
		assertNotNull(list);
	}

}
