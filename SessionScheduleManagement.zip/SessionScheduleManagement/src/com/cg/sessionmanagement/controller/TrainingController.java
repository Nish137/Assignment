package com.cg.sessionmanagement.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.cg.sessionmanagement.model.TrainingDetails;
import com.cg.sessionmanagement.service.ITrainingService;

@Controller
public class TrainingController extends AbstractController {

/*	@Autowired
	ITrainingService service;

	@RequestMapping("/home")
	public String displayPage(Model model) {
		String view = "ScheduledSessions";
		ArrayList<TrainingDetails> list = service.getAllTrainings();
		model.addAttribute("traininglist", list);
		return view;
	}

	@RequestMapping("/enroll")
	public String successPage(Model model,@ModelAttribute("name")String name) {
		String view = "";
		String trainingName = service.findTrainingName(name);
		model.addAttribute("trainingname", trainingName);
		view = "Success";
		return view;
	}*/

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView modelandview=new ModelAndView("ScheduledSession");
				modelandview.addObject("welcomeMessage","HiMatthew,Welcome to Spring World");
		return modelandview;
		
	
	}
}
