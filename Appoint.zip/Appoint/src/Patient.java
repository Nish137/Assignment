import java.util.HashMap;
import java.util.Scanner;

public class Patient {
	int id;
	String name;
	long phone;
public static void main(String args[])
{
	Scanner s = new Scanner(System.in);
	HashMap<Integer,Patient> map=new HashMap<Integer,Patient>();
	char choice='y';
	do {
	Patient p=new Patient();
	System.out.println("enter id");
	p.id=s.nextInt();
	System.out.println("enter name");
	p.name=s.next();
	System.out.println("enter phone");
	p.phone=s.nextLong();
	map.put(p.id,p );
	System.out.println("Do you want to add one more Y/N ?");	
	choice=s.next().charAt(0);
	}while(choice=='y');
	
	System.out.println("DO you want to search a patient y/n");
	choice=s.next().charAt(0);
	System.out.println("Enter id to search");
	int id=s.nextInt();
	
	if(choice=='y')
	{
		for(Patient p:map.values())
		{
			if(p.id==id)
			{
				System.out.println("patient details are :");
				System.out.println("Name :"+p.name);
				System.out.println("Phone :"+p.phone);
				break;
			}
			
		}
	}
		
		
}
}
