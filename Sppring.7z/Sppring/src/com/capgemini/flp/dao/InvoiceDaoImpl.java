package com.capgemini.flp.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.exception.InvoiceException;
import com.cg.sheela.dto.MerchantProduct;
import com.cg.sheela.dto.Order;




@Repository
public class InvoiceDaoImpl implements InvoiceDao {
	@PersistenceContext 
	EntityManager entityManager;
		
		
	

	
		@Override
		public String getInvoice(int productid, int orderid)
				throws InvoiceException {
			Order a=entityManager.find(Order.class, 1001);
			MerchantProduct b=entityManager.find(MerchantProduct.class,100);
			System.out.println(a.getCustomerEmailId());
			System.out.println(b.getProduct_Category());
			return "invoice";
		
			
		}
		}


