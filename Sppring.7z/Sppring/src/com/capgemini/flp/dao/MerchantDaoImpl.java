package com.capgemini.flp.dao;

public class MerchantDaoImpl {

}
