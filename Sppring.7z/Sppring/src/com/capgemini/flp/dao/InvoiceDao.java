package com.capgemini.flp.dao;

import java.util.List;


import com.capgemini.flp.exception.InvoiceException;

public interface InvoiceDao {
	public String getInvoice(int productid, int orderid)throws InvoiceException;
}
