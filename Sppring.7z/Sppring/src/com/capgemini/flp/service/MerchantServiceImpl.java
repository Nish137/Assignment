package com.capgemini.flp.service;

public class MerchantServiceImpl  implements MerchantService{

}
