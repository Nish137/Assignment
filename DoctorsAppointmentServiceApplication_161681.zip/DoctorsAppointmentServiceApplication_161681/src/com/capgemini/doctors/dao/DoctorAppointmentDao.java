/**
	 @author Gundrapally ShivaKumar
	 @creation Date 29/10/2018  */

package com.capgemini.doctors.dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.doctors.bean.DoctorAppointment;

public class DoctorAppointmentDao implements IDoctorAppointmentDao { //Data Access Class which stores the customer Details  

	Map<Long, DoctorAppointment> custMap = new HashMap<Long, DoctorAppointment>();
	// Map<Long, String> patient = new HashMap<Long, String>();

	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) {
		// TODO Auto-generated method stub
		long key = doctorAppointment.getAppointmentId();
		custMap.put(key, doctorAppointment);
		if (custMap.containsValue(doctorAppointment)) {

			return 1;
		}
		return 0;
	}

	@Override
	public DoctorAppointment getDoctorAppointmentDetails(int appointmentId) {
		// TODO Auto-generated method stub
		for (DoctorAppointment c : custMap.values()) {
			if (c.getAppointmentId() == appointmentId) {
				System.out.println("Name:" + c.getPatientName() + "\nDoctor Name:" + c.getDoctorName() + "\nStatus:"
						+ c.getAppointmentStatus());
			}
		}
		return null;
	}

	public static boolean validateAppointmentId(int appointmentid) {
		// TODO Auto-generated method stub
		DoctorAppointmentDao d= new DoctorAppointmentDao();
		for (long c : d.custMap.keySet()) {
			
			if (appointmentid==c) {
				System.out.println("sai");
			}
		}
		return false;
	}

}
