/**
	 @author Gundrapally ShivaKumar
	 @creation Date 29/10/2018  */

package com.capgemini.doctors.ui; 
import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.service.DoctorServiceImp;

public class Client {  //User Class it will retrieve data and display to the customer

	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("*****************************");
		System.out.println("Welcome To Sunrise Hospital:");
		System.out.println("*****************************");
		while (true) {
			System.out.println("Enter your Choice:");
			System.out.println("1.Book Doctor Appointment:");
			System.out.println("2.View Doctor Appoitnment:");
			System.out.println("3.Exit:");
			
			int choice = sc.nextInt();
			DoctorServiceImp service=new DoctorServiceImp();
			switch (choice) {
			case 1:
				DoctorAppointment bean = new DoctorAppointment();

				boolean b;

				
				do {

					System.out.println("Enter your Name:");
					String paitentName = sc.next();
					bean.setPatientName(paitentName);
					b = service.validateLetters(paitentName);
					if (b) {
						break;
					} else
						System.err.println("Please Enter your name Staring with capital letter:");
				} while (!b);

			
				do {
					System.out.println("Enter your Phone Number:");
					String phoneNumber = sc.next();
					bean.setPhoneNumber(phoneNumber);
					b = service.validatePhoneNumber(phoneNumber);
					if (b) {
						break;
					} else
						System.err.println("Phone Number must be in the form XXXXXXXXXX");
				} while (!b);

				do { 
					System.out.println("Enter your Age:");
					int age = sc.nextInt();
					bean.setAge(age);
					b = service.validateage(age);
					if (b) {
                        break;
					} else
						System.err.println("Age should be greater than 15:");
		} while (!b);

				
				do {
					System.out.println("ENTER GENDER");
					String gender = sc.next().toUpperCase();
					b = service.validateGender(gender);
					bean.setGender(gender);
					if (b) {
                        break;
					}
		        } while (!b);
				
				do {
					System.out.println("Enter Problem Name::");
					System.out.println("Enter Heart      :Dr.Brijesh Kumar");
					System.out.println("Enter Gynecology :Dr.Sharda Singh");
					System.out.println("Enter Diabetes   :Dr.Heena Khan ");
					System.out.println("Enter ENT        :Dr.Paras mal");
					System.out.println("Enter Bone       :Dr.Renuka kher");
					System.out.println("Enter Dermatology:Dr.Kanika kapoor");

				    String problemName=	sc.next();
				 bean.setProblemName(problemName);
					
			     b=	service.validateProblemName(problemName);
			     if(b) {
			    	 break;
			     }else
			    	 System.err.println("/nEnter valid Problem:");
				} while(!b);	 
				     
									
				     
				
				
				    do {
					System.out.println("Enter your E-mail:");
					String email = sc.next();
					bean.setEmail(email);
					b = service.validateEmail(email);
					if (b) {

					} else
						System.out.println("Enter valid Email:");
				} while (!b);

				int isadded=service.addDoctorAppointmentDetails(bean);
				if(isadded==1) {
				System.out.println("Congratulations!!: Your Doctor Appointment has been successfully registered!!:");

				System.err.println("*****************************************\n");
				
				System.out.println("your appointment_id is :" + bean.getAppointmentId());
				
				System.out.println(bean);
			}else {
				System.out.println("Appointment not registered.");
			}
				break;
				
			case 2:
				 System.out.println(" Enter your Appointment_id to your view doctor Apppointment:");
				int appointmentid= sc.nextInt();
				
				boolean isvalid=service.validateAppointmentId(appointmentid); if(isvalid) {
				 
				DoctorServiceImp i=new DoctorServiceImp();
				i.validateAppointmentId(appointmentid);
				}else {
					System.err.println("please enter valid appointment id");
				}
				 break;
			case 3:
				System.out.println("Thank you for  using Services:");
				sc.close();
                System.exit(0);
}
	
		}
	}
	}

	
	

