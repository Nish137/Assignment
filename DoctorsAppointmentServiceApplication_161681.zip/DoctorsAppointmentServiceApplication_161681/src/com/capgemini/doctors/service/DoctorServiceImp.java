/**
	 @author Gundrapally ShivaKumar
	 @creation Date 29/10/2018  */

package com.capgemini.doctors.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;

public class DoctorServiceImp implements IDoctorAppointmentService { // service class will implement Business logics
	DoctorAppointment bean = new DoctorAppointment();
	DoctorAppointmentDao dao = new DoctorAppointmentDao();

	public boolean validateLetters(String paitentName) {
		Pattern pattern = Pattern.compile("^[A-Z][a-z]{1,}\\.?");
		Matcher matcher = pattern.matcher(paitentName);
		return matcher.matches();

	}

	public boolean validateage(int age) {
		if (age > 15 && age < 100) {
			return true;
		}
		return false;
	}

	public boolean validateGender(String gender) {
		if (gender.equals("M") || (gender.equals("MALE"))) {
			return true;
		} else if (gender.matches("F") || gender.matches("FEMALE")) {
			return true;
		}

		return false;

	}

	public boolean validateEmail(String email) {
		Pattern p = Pattern.compile("[a-zA-Z0-9-.]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+");
		Matcher matcher = p.matcher(email);

		return matcher.matches();
	}

	public boolean validatePhoneNumber(String phoneNumber) {
		Pattern pattern = Pattern.compile("(0/91)?[7-9][0-9]{9}");
		Matcher matcher = pattern.matcher(phoneNumber);

		return matcher.matches();

	}

	public boolean validateProblemName(String problemName) {
		if (problemName.equals("Heart")) {
			bean.setDoctorName("Dr.Dr.Brijesh Kumar");
			bean.setAppointmentStatus("APPROVED");
			return true;
		} else if (problemName.equals("Gynecology")) {
			bean.setDoctorName("Dr.Sharda Singh");
			bean.setAppointmentStatus("APPROVED");
			return true;
		} else if (problemName.equals("Diabetes")) {
			bean.setDoctorName("Dr.Heena Khan");
			bean.setAppointmentStatus("APPROVED");
			return true;
		} else if (problemName.equals("ENT ")) {
			bean.setDoctorName("Dr.Paras mal");
			bean.setAppointmentStatus("APPROVED");
			return true;
		} else if (problemName.equals("Bone")) {
			bean.setDoctorName("Dr.Renuka kher");
			bean.setAppointmentStatus("APPROVED");
			return true;
		} else if (problemName.equals("Dermatology")) {
			bean.setDoctorName("Dr.Kanika kapoor");
			bean.setAppointmentStatus("APPROVED");
			return true;
		} else {
			bean.setDoctorName("Null");
			bean.setAppointmentStatus("DISAPPROVED");
		}

		return false;

	}

	@Override
	public int addDoctorAppointmentDetails(DoctorAppointment doctorAppointment) {
		// TODO Auto-generated method stub
		return dao.addDoctorAppointmentDetails(doctorAppointment);
	}

	@Override
	public DoctorAppointment getDoctorAppointmentDetails(int appointmentId) {
		// TODO Auto-generated method stub
		return dao.getDoctorAppointmentDetails(appointmentId);
	}

	public  boolean validateAppointmentId(int appointmentid) {
		// TODO Auto-generated method stub
		return DoctorAppointmentDao.validateAppointmentId(appointmentid);
	}
}
