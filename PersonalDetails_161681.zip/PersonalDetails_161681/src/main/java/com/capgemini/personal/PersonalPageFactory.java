package com.capgemini.personal;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class PersonalPageFactory {
	WebDriver wd;

	public PersonalPageFactory(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}

	@FindBy(name = "txtFN")
	@CacheLookup
	WebElement fname;

	@FindBy(name = "txtLN")
	@CacheLookup
	WebElement lname;

	@FindBy(xpath = "//*[@id=\"txtEmail\"]")
	@CacheLookup
	WebElement email;

	@FindBy(xpath = "//*[@id=\"txtPhone\"]")
	@CacheLookup
	WebElement contactNo;

	@FindBy(xpath = "//*[@id=\"txtAddress1\"]")
	@CacheLookup
	WebElement adressLine1;

	@FindBy(xpath = "//*[@id=\"txtAddress2\"]")
	@CacheLookup
	WebElement adressLine2;

	@FindBy(xpath = "/html/body/form/table/tbody/tr[9]/td[2]/select")
	@CacheLookup
	WebElement city;

	public Select getSelectOptions(WebElement select) {
		return new Select(select);
	}

	@FindBy(xpath = "/html/body/form/table/tbody/tr[10]/td[2]/select")

	@CacheLookup
	WebElement state;

	@FindBy(xpath = "/html/body/form/table/tbody/tr[11]/td/a")
	@CacheLookup
	WebElement next;

	

	public WebDriver getWd() {
		return wd;
	}

	public void setWd(WebDriver wd) {
		this.wd = wd;
	}

	public WebElement getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname.sendKeys(fname);
	}

	public WebElement getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname.sendKeys(lname);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo.sendKeys(contactNo);
	}

	public WebElement getAdressLine1() {
		return adressLine1;
	}

	public void setAdressLine1(String adressLine1) {
		this.adressLine1.sendKeys(adressLine1);
	}

	public WebElement getAdressLine2() {
		return adressLine2;
	}

	public void setAdressLine2(String adressLine2) {
		this.adressLine2.sendKeys(adressLine2);
	}

	public String getCity() {
		return getSelectOptions(city).getFirstSelectedOption().getText();
	}

	public void setCity(String value) {
		getSelectOptions(city).selectByVisibleText(value);
	}

	public String getState() {
		return getSelectOptions(state).getFirstSelectedOption().getText();
	}

	public void setState(String value) {
		getSelectOptions(city).selectByVisibleText(value);
	}

	public WebElement getNext() {
		return next;
	}

	public void setNext() {
		next.click();
	}

	public PersonalPageFactory(WebDriver wd, WebElement fname, WebElement lname, WebElement email, WebElement contactNo,
			WebElement adressLine1, WebElement adressLine2, WebElement city, WebElement state, WebElement next) {
		super();
		this.wd = wd;
		this.fname = fname;
		this.lname = lname;
		this.email = email;
		this.contactNo = contactNo;
		this.adressLine1 = adressLine1;
		this.adressLine2 = adressLine2;
		this.city = city;
		this.state = state;
		this.next = next;
	}

	public void setCity() {
		// TODO Auto-generated method stub
		
	}

	public void setState() {
		// TODO Auto-generated method stub
		
	}

}
