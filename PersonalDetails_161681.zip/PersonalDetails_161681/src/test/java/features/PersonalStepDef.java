package features;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.personal.PersonalPageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDef {
	private PersonalPageFactory personal ;
	private WebDriver driver;
	
	public PersonalStepDef(WebDriver driver2) {
		// TODO Auto-generated constructor stub
	}

	public PersonalStepDef() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Given("^user is on the webpage$")
	public void user_is_on_the_webpage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\\\ChromeTestDriver\\\\chromedriver.exe.");
		driver = new ChromeDriver();
		personal=new PersonalPageFactory(driver);
	    driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	    driver.get("file:///D:/SpringJPAWS/PersonalDetails_161681/src/test/java/features/Personal.html");
	   
	}

	@Then("^check the heading of the page$")
	public void check_the_heading_of_the_page() throws Throwable {
		if(driver.getTitle().contentEquals("HTML Form Demo"))
			   System.out.println("********** Title Matched");
		   else
			   System.out.println("*********** Title mismatch");
		   
		   driver.close();
	}

	@When("^user leaves first name blank and clicks the next$")
	public void user_leaves_first_name_blank_and_clicks_the_next() throws Throwable {
		
		personal.setFname("");
		personal.setNext();
		
		
		
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^display error message$")
	public void display_error_message() throws Throwable {
		
		String str=driver.findElement(By.xpath(".//*[@id='userErrMsg']")).getText();
		 assertEquals(str, "* Please enter userName.");
		   
		    driver.close();
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^user leaves last name blank and clicks the next$")
	public void user_leaves_last_name_blank_and_clicks_the_next() throws Throwable {
		
		personal.setFname("Matthew");
		personal.setLname("");
		personal.setNext();
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^user enters wrong email and clicks the next$")
	public void user_enters_wrong_email_and_clicks_the_next() throws Throwable {
		
		String str=driver.findElement(By.xpath(".//*[@id='userErrMsg']")).getText();
		 assertEquals(str, "* Please enter userName.");
		   
		    driver.close();
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^diaplay error message$")
	public void diaplay_error_message() throws Throwable {
		
		String str=driver.findElement(By.xpath(".//*[@id='userErrMsg']")).getText();
		 assertEquals(str, "* Please enter userName.");
		   
		    driver.close();
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^user leaves conatact number blank and clicks the next$")
	public void user_leaves_conatact_number_blank_and_clicks_the_next() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^user enters wrong Conatact no and clicks the next$")
	public void user_enters_wrong_Conatact_no_and_clicks_the_next() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^user leaves Addressline(\\d+)  blank and clicks the next$")
	public void user_leaves_Addressline_blank_and_clicks_the_next(int arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^user not selecting the city and clicks next$")
	public void user_not_selecting_the_city_and_clicks_next() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^Display error message$")
	public void display_error_message1() throws Throwable {
		
		String str=driver.findElement(By.xpath(".//*[@id='userErrMsg']")).getText();
		 assertEquals(str, "* Please enter userName.");
		   
		    driver.close();
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^user not selecting the State and clicks next$")
	public void user_not_selecting_the_State_and_clicks_next() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^user enter all valid details$")
	public void user_enter_all_valid_details() throws Throwable {
		 personal.setFname("Matthew");
		    Thread.sleep(1000);
		    personal.setLname("Gundrapally");
		    Thread.sleep(1000);
		    personal.setAdressLine1("hyderabd");
		    Thread.sleep(1000);
		    personal.setAdressLine2("telangana");
		    Thread.sleep(1000);
		    		personal.setEmail("nishanthmathew7@gmail.com");
		    		Thread.sleep(1000);
		    		personal.setCity();
		    		Thread.sleep(1000);
		    		personal.setState();
		    		Thread.sleep(1000);
		    		
		    
		    
	   
	}

	@Then("^navigate to Educational deatails form$")
	public void navigate_to_Educational_deatails_form() throws Throwable {
		personal.setNext();
	    System.out.println("all Valid Credentials");
		driver.navigate().to("file:///D:/SpringJPAWS/PersonalDetails_161681/src/test/java/features/Education.html");
		Thread.sleep(3000);
		System.out.println(" person deatils are accepted Successfully");
		driver.close();
	    // Write code here that turns the phrase above into concrete actions
	    
	}


}
