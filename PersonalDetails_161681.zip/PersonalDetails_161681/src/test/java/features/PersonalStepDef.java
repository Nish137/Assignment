package features;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.personal.PersonalPageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDef {
	private PersonalPageFactory personal;
	private WebDriver driver;

	public PersonalStepDef(WebDriver driver2) {
		// TODO Auto-generated constructor stub
	}

	public PersonalStepDef() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Given("^user is on the webpage$")
	public void user_is_on_the_webpage() throws Throwable {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\asus\\Downloads\\chromedriver.exe");
		driver = new ChromeDriver();
		personal = new PersonalPageFactory(driver);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.get("file:///C:/workspace/PersonalDetails_161681/src/test/java/features/Personal.html");

	}

	@Then("^check the heading of the page$")
	public void check_the_heading_of_the_page() throws Throwable {
		String strheading=driver.findElement(By.xpath("/html/body/h4")).getText();
		if(strheading.contentEquals("Step 2:Personal Details"))
			System.out.println("********** Heading Matched");
		else
			System.out.println("********** Heading Not Matched");
		Thread.sleep(3000);
		driver.close();
	}

	@When("^user leaves first name blank and clicks the next$")
	public void user_leaves_first_name_blank_and_clicks_the_next() throws Throwable {

		personal.setFname("");
		personal.setNext();

		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^display error message for firstname$")
	public void display_error_message_for_firstname() throws Throwable {

		String alertMessage = driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please fill the First Name");
		System.out.println("*******************" + alertMessage);
		driver.close();
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^user leaves last name blank and clicks the next$")
	public void user_leaves_last_name_blank_and_clicks_the_next() throws Throwable {

		personal.setFname("Matthew");
		personal.setLname("");
		personal.setNext();
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^display error message for last name$")
	public void display_error_message_for_last_name() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please fill the Last Name");
		System.out.println("*******************" + alertMessage);
		driver.close();
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^user enters wrong email and clicks the next$")
	public void user_enters_wrong_email_and_clicks_the_next() throws Throwable {

		personal.setFname("Matthew");
		personal.setLname("Gundrapally");
		personal.setEmail("nsnj3gail.com");
		personal.setNext();

		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^display error message for email$")
	public void display_error_message_for_email() throws Throwable {

		String alertMessage = driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please fill the Email");
		System.out.println("*******************" + alertMessage);
		driver.close();
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^user leaves conatact number blank and clicks the next$")
	public void user_leaves_conatact_number_blank_and_clicks_the_next() throws Throwable {
		personal.setFname("Matthew");
		personal.setLname("Gundrapally");
		personal.setEmail("nishnath@gmail.com");
		personal.setContactNo("");
		personal.setNext();
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^display error message for contact number$")
	public void display_error_message_for_contact_number() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please fill the Conatact No");
		System.out.println("*******************" + alertMessage);
		driver.close();
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^user enters wrong Conatact no and clicks the next$")
	public void user_enters_wrong_Conatact_no_and_clicks_the_next() throws Throwable {

		personal.setFname("Matthew");
		personal.setLname("Gundrapally");
		personal.setEmail("nishnath@gmail.com");
		personal.setContactNo("523654654");
		personal.setNext();
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^display error message for wrong contact number$")
	public void display_error_message_for_wrong_contact_number() throws Throwable {

		String alertMessage = driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please fill the Conatact No");
		System.out.println("*******************" + alertMessage);
		driver.close();
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^user leaves Addressline  blank and clicks the next$")
	public void user_leaves_Addressline_blank_and_clicks_the_next() throws Throwable {

		personal.setFname("Matthew");
		personal.setLname("Gundrapally");
		personal.setEmail("nishnath@gmail.com");
		personal.setContactNo("9885022003");
		personal.setAdressLine1("");
		personal.setNext();

		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^display error message for  an address$")
	public void display_error_message_for_an_address() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please fill the AddressLine1");
		System.out.println("*******************" + alertMessage);
		driver.close();
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^user leaves Addressline empty and clicks the next$")
	public void user_leaves_Addressline_empty_and_clicks_the_next() throws Throwable {
		personal.setFname("Matthew");
		personal.setLname("Gundrapally");
		personal.setEmail("nishnath@gmail.com");
		personal.setContactNo("9885022003");
		personal.setAdressLine1("2-57,Hyderabad");
		personal.setAdressLine2("");
		personal.setNext();
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^display error message for  the address$")
	public void display_error_message_for_the_address() throws Throwable {

		String alertMessage = driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please fill the AddressLine2");
		System.out.println("*******************" + alertMessage);
		driver.close();
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^user not selecting the city and clicks next$")
	public void user_not_selecting_the_city_and_clicks_next() throws Throwable {

		personal.setFname("Matthew");
		personal.setLname("Gundrapally");
		personal.setEmail("nishnath@gmail.com");
		personal.setContactNo("9885022003");
		personal.setAdressLine1("2-57,Hyderabad");
		personal.setAdressLine2("Telangana");
		// personal.setCity("");
		personal.setNext();
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^Display error message for city$")
	public void display_error_message_for_city() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	
		String alertMessage = driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please Select the city");
		System.out.println("*******************" + alertMessage);
		driver.close();
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^user not selecting the State and clicks next$")
	public void user_not_selecting_the_State_and_clicks_next() throws Throwable {
		personal.setFname("Matthew");
		personal.setLname("Gundrapally");
		personal.setEmail("nishnath@gmail.com");
		personal.setContactNo("9885022003");
		personal.setAdressLine1("2-57,Hyderabad");
		personal.setAdressLine2("Telangana");
		personal.setCity("Pune");
		// personal.setState();
		personal.setNext();
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^Display error message for state$")
	public void display_error_message_for_state() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Please Select the State");
		System.out.println("*******************" + alertMessage);
		driver.close();
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^user enter all valid details$")
	public void user_enter_all_valid_details() throws Throwable {
		personal.setFname("Matthew");
		personal.setLname("Gundrapally");
		personal.setEmail("nishnath@gmail.com");
		personal.setContactNo("9885022003");
		personal.setAdressLine1("2-57,Hyderabad");
		personal.setAdressLine2("Telangana");
		personal.setCity("Hyderabad");
		personal.setState("Maharastra");
		personal.setNext();
	}

	@Then("^navigate to Educational deatails form$")
	public void navigate_to_Educational_deatails_form() throws Throwable {
		String alertMessage=driver.switchTo().alert().getText();
		assertEquals(alertMessage, "Personal details are validated and accepted successfully.");
	    System.out.println("*******************"+alertMessage);
	    driver.switchTo().alert().accept();
		driver.navigate().to("file:///C:/workspace/PersonalDetails_161681/src/test/java/features/TEducation.html");
		Thread.sleep(2000);
		System.out.println("\n********************* Successfully Entered to educational details page ");
		driver.close();
	}
}
		

	


