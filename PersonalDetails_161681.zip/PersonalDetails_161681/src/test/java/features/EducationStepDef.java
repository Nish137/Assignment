package features;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.capgemini.personal.EducationPageFactory;
import com.capgemini.personal.PersonalPageFactory;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EducationStepDef {
	
	private EducationPageFactory edu ;
	private WebDriver driver;
	
	public EducationStepDef() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Given("^user on the webpage$")
	public void user_on_the_webpage() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver", "D:\\\\ChromeTestDriver\\\\chromedriver.exe.");
		driver = new ChromeDriver();
		edu=new EducationPageFactory (driver);
	    driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	    
	   
	    // Write code here that turns the phrase above into concrete actions
	  
	}

	@Then("^Checks the heading of the page$")
	public void checks_the_heading_of_the_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^user not selects the graduation and clicks the Register me$")
	public void user_not_selects_the_graduation_and_clicks_the_Register_me() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   ;
	}

	@Then("^dispaly error message$")
	public void dispaly_error_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^user levaes the percentage blank and clicks Register me$")
	public void user_levaes_the_percentage_blank_and_clicks_Register_me() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("^print  error message$")
	public void print_error_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^user levaes the passsing  blank and clicks Register me$")
	public void user_levaes_the_passsing_blank_and_clicks_Register_me() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("^Display an error message$")
	public void display_an_error_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("^user levaes the Project blank and clicks Register me$")
	public void user_levaes_the_Project_blank_and_clicks_Register_me() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@Then("^display  the error message$")
	public void display_the_error_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	}

	@When("^user not selects the technologies and clicks on Making payment$")
	public void user_not_selects_the_technologies_and_clicks_on_Making_payment() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^user not selects the Other and not filled the form$")
	public void user_not_selects_the_Other_and_not_filled_the_form() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("^user enter all valid Education details$")
	public void user_enter_all_valid_Education_details() throws Throwable {
		
		edu.setGraduation();
		edu.setJava();
		edu.setOther();
		
		edu.setNet();
		edu.setOtherTechology("python");
		
		edu.setPassing("2018");
		edu.setPercentage("60");
		edu.setProjectName("Doctor Appointment");
		
		edu.setRegister();
		
	
	    // Write code here that turns the phrasbove into concrete actions
	   
	}

	@Then("^print the suceess message$")
	public void print_the_suceess_message() throws Throwable {
		
		
		edu.setRegister();
	    System.out.println("all Valid Credentials");
		driver.navigate().to("Make payment");
		
		driver.close();
	    // Write code here that turns the phrase above into concrete actions
	    
	}



}
