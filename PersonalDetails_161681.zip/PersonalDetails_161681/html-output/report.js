$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/TEducationDeatils.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    }
  ],
  "line": 2,
  "name": "Education Deatils",
  "description": "",
  "id": "education-deatils",
  "keyword": "Feature"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "TEducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 4084579804,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "Test the Title",
  "description": "",
  "id": "education-deatils;test-the-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "Checks the heading of the page",
  "keyword": "Then "
});
formatter.match({
  "location": "TEducationStepDef.checks_the_heading_of_the_page()"
});
formatter.result({
  "duration": 3278147722,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "TEducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 2660661051,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Failure on not selecting the graduation",
  "description": "",
  "id": "education-deatils;failure-on-not-selecting-the-graduation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "user not selects the graduation and clicks the Register me",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "dispaly error message",
  "keyword": "Then "
});
formatter.match({
  "location": "TEducationStepDef.user_not_selects_the_graduation_and_clicks_the_Register_me()"
});
formatter.result({
  "duration": 43520,
  "status": "passed"
});
formatter.match({
  "location": "TEducationStepDef.dispaly_error_message()"
});
formatter.result({
  "duration": 40211610,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 10.0.17134 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027DESKTOP-LOK3I80\u0027, ip: \u0027192.168.0.120\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_191\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\asus\\AppData\\Local...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:53447}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: 9de0b256460902e8057af44e723e0e1c\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat features.TEducationStepDef.dispaly_error_message(TEducationStepDef.java:66)\r\n\tat ✽.Then dispaly error message(features/TEducationDeatils.feature:12)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "TEducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 2511913168,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Failure in login apge on leaving percentage empty",
  "description": "",
  "id": "education-deatils;failure-in-login-apge-on-leaving-percentage-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user levaes the percentage blank and clicks Register me",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "print  error message",
  "keyword": "Then "
});
formatter.match({
  "location": "TEducationStepDef.user_levaes_the_percentage_blank_and_clicks_Register_me()"
});
formatter.result({
  "duration": 268767458,
  "status": "passed"
});
formatter.match({
  "location": "TEducationStepDef.print_error_message()"
});
formatter.result({
  "duration": 4219305,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 10.0.17134 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027DESKTOP-LOK3I80\u0027, ip: \u0027192.168.0.120\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_191\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\asus\\AppData\\Local...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:53457}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: fc5ab855628d2abe26bc69929f31c0af\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat features.TEducationStepDef.print_error_message(TEducationStepDef.java:87)\r\n\tat ✽.Then print  error message(features/TEducationDeatils.feature:16)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "TEducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 2762407782,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Failure in login apge on leaving passsing year empty",
  "description": "",
  "id": "education-deatils;failure-in-login-apge-on-leaving-passsing-year-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "user levaes the passsing  blank and clicks Register me",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "Display an error message",
  "keyword": "Then "
});
formatter.match({
  "location": "TEducationStepDef.user_levaes_the_passsing_blank_and_clicks_Register_me()"
});
formatter.result({
  "duration": 442747545,
  "status": "passed"
});
formatter.match({
  "location": "TEducationStepDef.display_an_error_message()"
});
formatter.result({
  "duration": 5806077,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 10.0.17134 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027DESKTOP-LOK3I80\u0027, ip: \u0027192.168.0.120\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_191\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\asus\\AppData\\Local...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:53468}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: aaefb88b9b9089aa897175c67a2f7b2e\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat features.TEducationStepDef.display_an_error_message(TEducationStepDef.java:106)\r\n\tat ✽.Then Display an error message(features/TEducationDeatils.feature:20)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "TEducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 4708444711,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "Failure in login apge on leaving Projec tName empty",
  "description": "",
  "id": "education-deatils;failure-in-login-apge-on-leaving-projec-tname-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 23,
  "name": "user levaes the Project blank and clicks Register me",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "display  the error message",
  "keyword": "Then "
});
formatter.match({
  "location": "TEducationStepDef.user_levaes_the_Project_blank_and_clicks_Register_me()"
});
formatter.result({
  "duration": 603225342,
  "status": "passed"
});
formatter.match({
  "location": "TEducationStepDef.display_the_error_message()"
});
formatter.result({
  "duration": 4363945,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 10.0.17134 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027DESKTOP-LOK3I80\u0027, ip: \u0027192.168.0.120\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_191\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\asus\\AppData\\Local...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:53480}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: bf11bb25bdc5ef4a6186ad8c16c88299\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat features.TEducationStepDef.display_the_error_message(TEducationStepDef.java:127)\r\n\tat ✽.Then display  the error message(features/TEducationDeatils.feature:24)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "TEducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 3120311842,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "Failure on not selecting the technologies",
  "description": "",
  "id": "education-deatils;failure-on-not-selecting-the-technologies",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 25,
      "name": "@Tet"
    }
  ]
});
formatter.step({
  "line": 27,
  "name": "user not selects the technologies and clicks on Making payment",
  "keyword": "When "
});
formatter.step({
  "line": 28,
  "name": "dispaly error message for technologies",
  "keyword": "Then "
});
formatter.match({
  "location": "TEducationStepDef.user_not_selects_the_technologies_and_clicks_on_Making_payment()"
});
formatter.result({
  "duration": 668547555,
  "status": "passed"
});
formatter.match({
  "location": "TEducationStepDef.dispaly_error_message_for_technologies()"
});
formatter.result({
  "duration": 3752105,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 10.0.17134 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027DESKTOP-LOK3I80\u0027, ip: \u0027192.168.0.120\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_191\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\asus\\AppData\\Local...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:53491}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: a63a6330d7b48049f0696caa4bf867eb\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat features.TEducationStepDef.dispaly_error_message_for_technologies(TEducationStepDef.java:150)\r\n\tat ✽.Then dispaly error message for technologies(features/TEducationDeatils.feature:28)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "TEducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 3540324889,
  "status": "passed"
});
formatter.scenario({
  "line": 30,
  "name": "Failure on not filling the technologies",
  "description": "",
  "id": "education-deatils;failure-on-not-filling-the-technologies",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 29,
      "name": "@test"
    }
  ]
});
formatter.step({
  "line": 31,
  "name": "user not selects the Other and not filled the form",
  "keyword": "When "
});
formatter.step({
  "line": 32,
  "name": "dispaly error message for other technologies",
  "keyword": "Then "
});
formatter.match({
  "location": "TEducationStepDef.user_not_selects_the_Other_and_not_filled_the_form()"
});
formatter.result({
  "duration": 905666600,
  "status": "passed"
});
formatter.match({
  "location": "TEducationStepDef.dispaly_error_message_for_other_technologies()"
});
formatter.result({
  "duration": 4702718,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 10.0.17134 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027DESKTOP-LOK3I80\u0027, ip: \u0027192.168.0.120\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_191\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\asus\\AppData\\Local...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:53505}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: 53f2a53a6d555ef1dec4acd7ed1daeea\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat features.TEducationStepDef.dispaly_error_message_for_other_technologies(TEducationStepDef.java:174)\r\n\tat ✽.Then dispaly error message for other technologies(features/TEducationDeatils.feature:32)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "TEducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 3363978084,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "succesfull Registration of Education",
  "description": "",
  "id": "education-deatils;succesfull-registration-of-education",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "user enter all valid Education details",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "print the suceess message",
  "keyword": "Then "
});
formatter.match({
  "location": "TEducationStepDef.user_enter_all_valid_Education_details()"
});
formatter.result({
  "duration": 796352940,
  "status": "passed"
});
formatter.match({
  "location": "TEducationStepDef.print_the_suceess_message()"
});
formatter.result({
  "duration": 4921598,
  "error_message": "org.openqa.selenium.NoAlertPresentException: no such alert\n  (Session info: chrome\u003d70.0.3538.110)\n  (Driver info: chromedriver\u003d2.43.600210 (68dcf5eebde37173d4027fa8635e332711d2874a),platform\u003dWindows NT 10.0.17134 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 0 milliseconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027DESKTOP-LOK3I80\u0027, ip: \u0027192.168.0.120\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_191\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, acceptSslCerts: false, applicationCacheEnabled: false, browserConnectionEnabled: false, browserName: chrome, chrome: {chromedriverVersion: 2.43.600210 (68dcf5eebde371..., userDataDir: C:\\Users\\asus\\AppData\\Local...}, cssSelectorsEnabled: true, databaseEnabled: false, goog:chromeOptions: {debuggerAddress: localhost:53521}, handlesAlerts: true, hasTouchScreen: false, javascriptEnabled: true, locationContextEnabled: true, mobileEmulationEnabled: false, nativeEvents: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: XP, platformName: XP, rotatable: false, setWindowRect: true, takesHeapSnapshot: true, takesScreenshot: true, unexpectedAlertBehaviour: , unhandledPromptBehavior: , version: 70.0.3538.110, webStorageEnabled: true}\nSession ID: accfd1fad8f0de8ec464657c4c7c983e\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.http.JsonHttpResponseCodec.reconstructValue(JsonHttpResponseCodec.java:40)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:80)\r\n\tat org.openqa.selenium.remote.http.AbstractHttpResponseCodec.decode(AbstractHttpResponseCodec.java:44)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:605)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver$RemoteTargetLocator.alert(RemoteWebDriver.java:928)\r\n\tat features.TEducationStepDef.print_the_suceess_message(TEducationStepDef.java:202)\r\n\tat ✽.Then print the suceess message(features/TEducationDeatils.feature:36)\r\n",
  "status": "failed"
});
formatter.uri("features/personal.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author:Shiva Kumar"
    }
  ],
  "line": 2,
  "name": "Personal Deatils Page",
  "description": "",
  "id": "personal-deatils-page",
  "keyword": "Feature"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2906380414,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "verify the title",
  "description": "",
  "id": "personal-deatils-page;verify-the-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "check the heading of the page",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.check_the_heading_of_the_page()"
});
formatter.result({
  "duration": 3190036826,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2834142791,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Failure in login page on leaving first Name blank",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-leaving-first-name-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "user leaves first name blank and clicks the next",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "display error message for firstname",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_leaves_first_name_blank_and_clicks_the_next()"
});
formatter.result({
  "duration": 326281674,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_firstname()"
});
formatter.result({
  "duration": 2326397301,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2866999951,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Failure in login page on leaving last Name blank",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-leaving-last-name-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user leaves last name blank and clicks the next",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "display error message for last name",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_leaves_last_name_blank_and_clicks_the_next()"
});
formatter.result({
  "duration": 501099733,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_last_name()"
});
formatter.result({
  "duration": 2312836133,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 2480290782,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Failure in login page on Entering wrong email format",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-entering-wrong-email-format",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "user enters wrong email and clicks the next",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "display error message for email",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_enters_wrong_email_and_clicks_the_next()"
});
formatter.result({
  "duration": 996658774,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_email()"
});
formatter.result({
  "duration": 19906552,
  "error_message": "org.junit.ComparisonFailure: expected:\u003cPlease [enter valid Email Id.]\u003e but was:\u003cPlease [fill the Email]\u003e\r\n\tat org.junit.Assert.assertEquals(Assert.java:115)\r\n\tat org.junit.Assert.assertEquals(Assert.java:144)\r\n\tat features.PersonalStepDef.display_error_message_for_email(PersonalStepDef.java:108)\r\n\tat ✽.Then display error message for email(features/personal.feature:20)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 3201979220,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "Failure in login page on leaving  conatact number  blank",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-leaving--conatact-number--blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 23,
  "name": "user leaves conatact number blank and clicks the next",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "display error message for contact number",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_leaves_conatact_number_blank_and_clicks_the_next()"
});
formatter.result({
  "duration": 1223608651,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_contact_number()"
});
formatter.result({
  "duration": 22826657,
  "error_message": "org.junit.ComparisonFailure: expected:\u003cPlease fill the Con[tact No.]\u003e but was:\u003cPlease fill the Con[atact No]\u003e\r\n\tat org.junit.Assert.assertEquals(Assert.java:115)\r\n\tat org.junit.Assert.assertEquals(Assert.java:144)\r\n\tat features.PersonalStepDef.display_error_message_for_contact_number(PersonalStepDef.java:129)\r\n\tat ✽.Then display error message for contact number(features/personal.feature:24)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 3663993743,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "Failure in login page on Entering  Wrong Conatact number format",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-entering--wrong-conatact-number-format",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 27,
  "name": "user enters wrong Conatact no and clicks the next",
  "keyword": "When "
});
formatter.step({
  "line": 28,
  "name": "display error message for wrong contact number",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_enters_wrong_Conatact_no_and_clicks_the_next()"
});
formatter.result({
  "duration": 1476733663,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_wrong_contact_number()"
});
formatter.result({
  "duration": 7347197,
  "error_message": "org.junit.ComparisonFailure: expected:\u003cPlease [enter valid Contact no.]\u003e but was:\u003cPlease [fill the Conatact No]\u003e\r\n\tat org.junit.Assert.assertEquals(Assert.java:115)\r\n\tat org.junit.Assert.assertEquals(Assert.java:144)\r\n\tat features.PersonalStepDef.display_error_message_for_wrong_contact_number(PersonalStepDef.java:152)\r\n\tat ✽.Then display error message for wrong contact number(features/personal.feature:28)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 3583946418,
  "status": "passed"
});
formatter.scenario({
  "line": 30,
  "name": "Failure in login page on leaving Address line blank",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-leaving-address-line-blank",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 31,
  "name": "user leaves Addressline  blank and clicks the next",
  "keyword": "When "
});
formatter.step({
  "line": 32,
  "name": "display error message for  an address",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_leaves_Addressline_blank_and_clicks_the_next()"
});
formatter.result({
  "duration": 1355153342,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_an_address()"
});
formatter.result({
  "duration": 6081704,
  "error_message": "org.junit.ComparisonFailure: expected:\u003cPlease fill the [address line ]1\u003e but was:\u003cPlease fill the [AddressLine]1\u003e\r\n\tat org.junit.Assert.assertEquals(Assert.java:115)\r\n\tat org.junit.Assert.assertEquals(Assert.java:144)\r\n\tat features.PersonalStepDef.display_error_message_for_an_address(PersonalStepDef.java:176)\r\n\tat ✽.Then display error message for  an address(features/personal.feature:32)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 3741181977,
  "status": "passed"
});
formatter.scenario({
  "line": 34,
  "name": "Failure in login page on leaving Address line empty",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-leaving-address-line-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "user leaves Addressline empty and clicks the next",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "display error message for  the address",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_leaves_Addressline_empty_and_clicks_the_next()"
});
formatter.result({
  "duration": 1208434685,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_the_address()"
});
formatter.result({
  "duration": 5787731,
  "error_message": "org.junit.ComparisonFailure: expected:\u003cPlease fill the [address line ]2\u003e but was:\u003cPlease fill the [AddressLine]2\u003e\r\n\tat org.junit.Assert.assertEquals(Assert.java:115)\r\n\tat org.junit.Assert.assertEquals(Assert.java:144)\r\n\tat features.PersonalStepDef.display_error_message_for_the_address(PersonalStepDef.java:200)\r\n\tat ✽.Then display error message for  the address(features/personal.feature:36)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 6483390940,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "Failure in login page on not selecting the city",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-not-selecting-the-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 39,
  "name": "user not selecting the city and clicks next",
  "keyword": "When "
});
formatter.step({
  "line": 40,
  "name": "Display error message for city",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_not_selecting_the_city_and_clicks_next()"
});
formatter.result({
  "duration": 1437915547,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_city()"
});
formatter.result({
  "duration": 5674664,
  "error_message": "org.junit.ComparisonFailure: expected:\u003cPlease [select] city\u003e but was:\u003cPlease [Select the] city\u003e\r\n\tat org.junit.Assert.assertEquals(Assert.java:115)\r\n\tat org.junit.Assert.assertEquals(Assert.java:144)\r\n\tat features.PersonalStepDef.display_error_message_for_city(PersonalStepDef.java:228)\r\n\tat ✽.Then Display error message for city(features/personal.feature:40)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 3874436320,
  "status": "passed"
});
formatter.scenario({
  "line": 42,
  "name": "Failure in login page on not selecting the State",
  "description": "",
  "id": "personal-deatils-page;failure-in-login-page-on-not-selecting-the-state",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 43,
  "name": "user not selecting the State and clicks next",
  "keyword": "When "
});
formatter.step({
  "line": 44,
  "name": "Display error message for state",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_not_selecting_the_State_and_clicks_next()"
});
formatter.result({
  "duration": 1357993660,
  "status": "passed"
});
formatter.match({
  "location": "PersonalStepDef.display_error_message_for_state()"
});
formatter.result({
  "duration": 4645971,
  "error_message": "org.junit.ComparisonFailure: expected:\u003cPlease [select s]tate\u003e but was:\u003cPlease [Select the S]tate\u003e\r\n\tat org.junit.Assert.assertEquals(Assert.java:115)\r\n\tat org.junit.Assert.assertEquals(Assert.java:144)\r\n\tat features.PersonalStepDef.display_error_message_for_state(PersonalStepDef.java:253)\r\n\tat ✽.Then Display error message for state(features/personal.feature:44)\r\n",
  "status": "failed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "PersonalStepDef.user_is_on_the_webpage()"
});
formatter.result({
  "duration": 3403605588,
  "status": "passed"
});
formatter.scenario({
  "line": 46,
  "name": "succesfull login with all valid data",
  "description": "",
  "id": "personal-deatils-page;succesfull-login-with-all-valid-data",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 47,
  "name": "user enter all valid details",
  "keyword": "When "
});
formatter.step({
  "line": 48,
  "name": "navigate to Educational deatails form",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalStepDef.user_enter_all_valid_details()"
});
