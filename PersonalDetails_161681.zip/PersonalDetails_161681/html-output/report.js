$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("features/TEducationDeatils.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "#Author: your.email@your.domain.com"
    }
  ],
  "line": 2,
  "name": "Education Deatils",
  "description": "",
  "id": "education-deatils",
  "keyword": "Feature"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "EducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 5224355388,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "Test the Title",
  "description": "",
  "id": "education-deatils;test-the-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "Checks the heading of the page",
  "keyword": "Then "
});
formatter.match({
  "location": "EducationStepDef.checks_the_heading_of_the_page()"
});
formatter.result({
  "duration": 15998,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "EducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 3361023143,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Failure on not selecting the graduation",
  "description": "",
  "id": "education-deatils;failure-on-not-selecting-the-graduation",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "user not selects the graduation and clicks the Register me",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "dispaly error message",
  "keyword": "Then "
});
formatter.match({
  "location": "EducationStepDef.user_not_selects_the_graduation_and_clicks_the_Register_me()"
});
formatter.result({
  "duration": 27074,
  "status": "passed"
});
formatter.match({
  "location": "EducationStepDef.dispaly_error_message()"
});
formatter.result({
  "duration": 38150,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "EducationStepDef.user_on_the_webpage()"
});
formatter.result({
  "duration": 2096778825,
  "error_message": "org.openqa.selenium.SessionNotCreatedException: session not created exception\nfrom disconnected: received Inspector.detached event\n  (Session info: chrome\u003d70.0.3538.102)\n  (Driver info: chromedriver\u003d2.38.552522 (437e6fbedfa8762dec75e2c5b3ddb86763dc9dcb),platform\u003dWindows NT 6.1.7601 SP1 x86_64) (WARNING: The server did not provide any stacktrace information)\nCommand duration or timeout: 1.56 seconds\nBuild info: version: \u00273.13.0\u0027, revision: \u00272f0d292\u0027, time: \u00272018-06-25T15:24:21.231Z\u0027\nSystem info: host: \u0027CHNSIPDT0T506\u0027, ip: \u002710.219.34.209\u0027, os.name: \u0027Windows 7\u0027, os.arch: \u0027x86\u0027, os.version: \u00276.1\u0027, java.version: \u00271.8.0_45\u0027\nDriver info: driver.version: ChromeDriver\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat sun.reflect.NativeConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(Unknown Source)\r\n\tat java.lang.reflect.Constructor.newInstance(Unknown Source)\r\n\tat org.openqa.selenium.remote.ErrorHandler.createThrowable(ErrorHandler.java:214)\r\n\tat org.openqa.selenium.remote.ErrorHandler.throwIfResponseFailed(ErrorHandler.java:166)\r\n\tat org.openqa.selenium.remote.JsonWireProtocolResponse.lambda$new$0(JsonWireProtocolResponse.java:53)\r\n\tat org.openqa.selenium.remote.JsonWireProtocolResponse$$Lambda$189/25242267.apply(Unknown Source)\r\n\tat org.openqa.selenium.remote.JsonWireProtocolResponse.lambda$getResponseFunction$2(JsonWireProtocolResponse.java:91)\r\n\tat org.openqa.selenium.remote.JsonWireProtocolResponse$$Lambda$191/31674609.apply(Unknown Source)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.lambda$createSession$0(ProtocolHandshake.java:123)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake$$Lambda$198/11122630.apply(Unknown Source)\r\n\tat java.util.stream.ReferencePipeline$3$1.accept(Unknown Source)\r\n\tat java.util.Spliterators$ArraySpliterator.tryAdvance(Unknown Source)\r\n\tat java.util.stream.ReferencePipeline.forEachWithCancel(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.copyIntoWithCancel(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.copyInto(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.wrapAndCopyInto(Unknown Source)\r\n\tat java.util.stream.FindOps$FindOp.evaluateSequential(Unknown Source)\r\n\tat java.util.stream.AbstractPipeline.evaluate(Unknown Source)\r\n\tat java.util.stream.ReferencePipeline.findFirst(Unknown Source)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.createSession(ProtocolHandshake.java:126)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.createSession(ProtocolHandshake.java:73)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:136)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:548)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.startSession(RemoteWebDriver.java:212)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.\u003cinit\u003e(RemoteWebDriver.java:130)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:181)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:168)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:123)\r\n\tat features.EducationStepDef.user_on_the_webpage(EducationStepDef.java:29)\r\n\tat ✽.Given user on the webpage(features/TEducationDeatils.feature:5)\r\n",
  "status": "failed"
});
formatter.scenario({
  "line": 14,
  "name": "Failure in login apge on leaving percentage empty",
  "description": "",
  "id": "education-deatils;failure-in-login-apge-on-leaving-percentage-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 15,
  "name": "user levaes the percentage blank and clicks Register me",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "print  error message",
  "keyword": "Then "
});
formatter.match({
  "location": "EducationStepDef.user_levaes_the_percentage_blank_and_clicks_Register_me()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "EducationStepDef.print_error_message()"
});
formatter.result({
  "status": "skipped"
});
formatter.background({
  "line": 4,
  "name": "",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user on the webpage",
  "keyword": "Given "
});
formatter.match({
  "location": "EducationStepDef.user_on_the_webpage()"
});
